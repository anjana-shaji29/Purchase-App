import React from 'react';
import './index.scss';

const PageDashboard = () => {

    return (
        <div className='dashboard-wrap'>
            <div className='dashboard-box' >
                 <img src='./computer.png' alt='COMPUTER' />
            </div>
            
        </div>
    );
};

export default PageDashboard;
