export const apiUrl: string = "https://info-shop-now.vijee.in";

// export const apiUrl: string = "http://localhost:8085";